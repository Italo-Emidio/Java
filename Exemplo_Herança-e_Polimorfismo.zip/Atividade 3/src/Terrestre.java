
public class Terrestre extends Transporte{

	@Override
	public void locomover() {
		System.out.println("Na terra");
		
	}

	@Override
	public void embarque() {
		System.out.println("Pontos de paradas");
		
	}

	
}
