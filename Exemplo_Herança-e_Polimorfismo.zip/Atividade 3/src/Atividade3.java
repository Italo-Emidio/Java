
public class Atividade3 {

	public static void man(String[] args) {
		�nibus oni = new �nibus();
		avi�o avi = new avi�o();
		navio nav = new navio();
		
		oni.locomover();
		avi.locomover();
		nav.locomover();
	}
}
