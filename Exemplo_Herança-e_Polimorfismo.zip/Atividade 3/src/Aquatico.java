
public class Aquatico extends Transporte{

	@Override
	public void locomover() {
		System.out.println("Na �gua");
		
	}

	@Override
	public void embarque() {
		System.out.println("Cais");
		
	}

}
