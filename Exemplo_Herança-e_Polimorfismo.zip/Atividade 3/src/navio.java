
public class navio extends Aquatico{

	@Override
	public void locomover() {
		System.out.println("Locomo��o no mar");
		
	}
	
	@Override
	public void embarque() {
		System.out.println("Cais e portos mar�timos");
		
	}
}
