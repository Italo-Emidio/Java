
public class �nibus extends Terrestre{

	@Override
	public void locomover() {
		System.out.println("Locomo��o na estrada");
		
	}
	
	@Override
	public void embarque() {
		System.out.println("Paradas de �nibus");
		
	}
}
