
public class avi�o extends A�reo{

	@Override
	public void locomover() {
		System.out.println("Locomo��o no espa�o a�reo");
		
	}
	
	@Override
	public void embarque() {
		System.out.println("Aeroportos e hangares");
		
	}
}
