
public class A�reo extends Transporte{

	@Override
	public void locomover() {
		System.out.println("No ar");
		
	}

	@Override
	public void embarque() {
		System.out.println("Aeroporto");
		
	}

	
}
